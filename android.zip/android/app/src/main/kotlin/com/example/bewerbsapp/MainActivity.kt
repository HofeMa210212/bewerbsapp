package com.example.bewerbsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
